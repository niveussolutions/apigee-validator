
var schema = {
  phone_number: {
    type: "string",
    phone: true,
    required: false
  },
  policy_number: {
    type: "string",
    required: false,
    minLength: 5,
    maxLength: 15
  },
  gender: {
    type: "string",
    required: true,
    validValues: ["Male", "Female", "Other"]
  },
  age: {
    type: "number",
    required: true,
    min: 18,
    max: 99,
    round: true // Add the round constraint here
  },
  birthdate: {
    type: "date",
    required: true,
    dateFormat: "yyyy-mm-dd" // example of specifying a date format
  },
  address: {
    type: "object",
    required: true,
    properties: {
      street: {
        type: "string",
        required: true
      },
      city: {
        type: "string",
        required: true,
        maxLength: 50
      },
      zip_code: {
        type: "string",
        required: true,
        validValues: ["12345", "67890"]
      }
    }
  }
};

var requestBody = JSON.parse(context.getVariable("request.content"));



var validationResult = validator.validateRequestBody(requestBody, schema);
if (validationResult.errors) {
  context.setVariable("isError",true);
  context.setVariable("statusCode",400);
  var responseBody={
    status:"faild",
    responseCode:400,
    message:validationResult.errors
  }
  context.setVariable("responseBody",JSON.stringify(responseBody));
} else {
   context.setVariable("isError",false)
}
